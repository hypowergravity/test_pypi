""" This is a test package created to numeric calualtions using numpy like addition, subtraction, multiplication and division """


__version__ = "0.1.0"